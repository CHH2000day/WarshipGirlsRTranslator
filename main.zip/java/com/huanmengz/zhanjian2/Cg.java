package com.huanmengz.zhanjian2;
import android.app.*;
import android.widget.*;
import android.support.v7.widget.*;
import android.content.*;

public class Cg extends Application
{public static LinearLayout main;
public static android.support.v7.widget.Toolbar toolbar;
public static RelativeLayout rl;
public static RelativeLayout mrl;
public static Context context;
public static void setToolbar(android.support.v7.widget.Toolbar bar){
	toolbar=bar;
}
public static void setMainLayout(RelativeLayout r){
	mrl=r;
}
public static RelativeLayout getMainLayout(){
	return mrl;
}
public static void setLayout(RelativeLayout rll){
	rl=rll;
}
public static RelativeLayout getRelativeLayout(){
	return rl;
}
public static void setmain(LinearLayout LinearLayout){
	main=LinearLayout;
}
public static LinearLayout getMain(){
	return main;
}
public static android.support.v7.widget.Toolbar getToolbar(){
	return toolbar;
}
public void setContext(Context ctx){
	context=ctx;
}
public Context getContext(){
	return context;
}
}
