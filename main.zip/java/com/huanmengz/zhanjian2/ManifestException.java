package com.huanmengz.zhanjian2;

public class ManifestException extends Exception
{public ManifestException(String msg){
	super(msg);
}
}
