package com.huanmengz.zhanjian2;

import android.util.*;
import java.io.*;

public class GetInfo
{

	int v=-1;
	//String flname="/storage/sdcard1/mod.manifest";
	String llll="mod.manifest";
	String[] manifest;
	String[] info;
	boolean[] en;
	String[] par;
	public GetInfo()
	{
		File fle = new File("/storage/sdcard1/ddddd");
		int rr =0;
		File[] l =fle.listFiles();
		for(int i=0;i<l.length;i++){
			if(l[i].isDirectory()){
				File[] lo= l[i].listFiles();
				for(int u=0;u<lo.length;u++){
					if(lo[u].isFile()){
						if(lo[u].getName().equals("mod.manifest")){rr=rr+1;}
					}
				}
			}
		}
		int ui=l.length;
		manifest = new String[rr];
		info = new String[rr];
		//situations=new String [ui];
		en = new boolean[rr];
		par = new String[rr];


		for (int i=0;i < l.length;i++)
		{
			if (l[i].isDirectory())
			{
				File[] lop=l[i].listFiles();
				for (int u = 0;u < lop.length;u++)
				{if (lop[u].isFile())
					{
						String iio = lop[u].getName();
						if (iio.equals(llll))
						{v = v + 1;
							System.out.println("pass!!!" + iio + "path: " + lop[u].getAbsolutePath());
							manifest[v] = lop[u].getAbsolutePath();
							par[v] = lop[u].getParentFile().getName();
							info[v] = "暂无介绍";


							for (int y=0;y < lop.length;y++)
							{	if (lop[y].isFile())
								{
									String pp = lop[y].getName();
									if (pp.equals("mod.info"))
									{
										System.out.println("info:" + lop[y].getAbsolutePath());
										String tmp=execShell("cat "+lop[y].getAbsolutePath());
										if (tmp==null||tmp.equals("")){tmp=new String("暂无介绍");}
										info[v] = tmp;
									}
									if (pp.equals("mos.enable"))
									{en[v] = true;}}
							}}
					}
				}}}}
	public String execShell(String cmd)
	{
		String n="";
		try
		{
			Process process= Runtime.getRuntime().exec(cmd);
			BufferedReader er = new BufferedReader(new InputStreamReader(process.getErrorStream()));
			BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String h = er.readLine();
			String tmp= br.readLine();
			Log.d(h+"a"+tmp,h+"a"+tmp);
			if (tmp != null)
			{
				n = tmp;
			}
			
			if(h!=null){return h;}
		}
		catch (IOException e)
		{

		}
		return n;
	}
	
	public String[] getManifest()
	{
		return manifest;
	}
	public String[] getInfo()
	{
		return info;
	}
	public boolean[] getEnable()
	{
		return en;
	}
	public String[] getPar()
	{
		return par;
	}
}
