package com.huanmengz.zhanjian2;
import android.content.*;

public class reg 
{
	private static long var=438233L;
	private static final int[] en ={5,1,2,0,3,8,4,7,9,6};
	private static final int[] de ={2,1,2,4,6,0,9,7,5,8};
	private static String signcode =null;
	public static Context ctx;
	public static final void init(Context context)
	{
		ctx = context;
	}
	public static final String getSignCode()
	{
		/*
		 long tmp =System.currentTimeMillis();
		 long tw = tmp-1458510000000L;
		 signcode=Long.toString(tw);
		 return signcode;*/
		long j =imei.getIMEI(ctx);
		long k=code.encode(j);
		long h = code.decode1(k);
		return String.valueOf(h);
	}
	public static final boolean VerifyAble(String cde, String key)
	{
		if ((cde == null || cde.equals("")) || (key == null || key.equals("")))
		{
			return false;
		}
		//long tmp0=Long.parseLong(cde);
		//long tmp1=code.decode(tmp0);
		String tmp0=calculateKey(cde);
		long tmp4 = tmp0.hashCode();
		long tmp5 = key.hashCode();

		if (tmp4 == tmp5)
		{return true;}
		else
		{return false;}


	}
	public static final String calculateKey(String cde)
	{
		long as = Long.parseLong(cde);
		long k =code.encode1(as);
		long g =code.decode(k);
		long h = code.encode1(g);
		String l = Long.toHexString(h);
		return l;
	}

	public static final boolean verifyAccess(Long imei, Long cde)
	{
		long q = code.decode1(cde);
		long w = code.decode(q);
		long e = code.encode1(w);
		long r = code.decode(e);
		if (r == imei)
		{return true;}
		else
		{return false;}

	}
}
