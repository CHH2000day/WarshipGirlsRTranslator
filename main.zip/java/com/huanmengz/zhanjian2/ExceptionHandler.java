package com.huanmengz.zhanjian2;

import android.content.*;
import java.io.*;
import android.widget.*;
import android.support.v7.app.*;
import android.os.*;

public class ExceptionHandler implements Thread.UncaughtExceptionHandler
	{private static ExceptionHandler exceptionHandler;
		private ExceptionHandler(){}
		public static ExceptionHandler getInstance()
			{
				if(exceptionHandler==null)
					exceptionHandler=new ExceptionHandler();
				return exceptionHandler;
			}
		private boolean inited=false;
		private Context ctx,ce;
		private Thread.UncaughtExceptionHandler defaultHandler;
		public void init(Context ctx)
			{	ce= ctx;
				if(inited)return;
				this.ctx=ctx;
				defaultHandler=Thread.getDefaultUncaughtExceptionHandler();
				Thread.setDefaultUncaughtExceptionHandler(this);
			}

		@Override
		public void uncaughtException(Thread p1,Throwable p2)
			{

//p1:出错线程
//p2:错误
				StringWriter stringWriter=new StringWriter();
				PrintWriter printWriter=new PrintWriter(stringWriter);
				p2.printStackTrace(printWriter);
//保存错误
				String filename=Long.toHexString(System.currentTimeMillis());
				File parent=ctx.getDir("error",0);
				File file=new File(parent,filename);
				try{
						FileOutputStream fos=new FileOutputStream(file);
						fos.write(stringWriter.toString().getBytes());
						fos.close();
					}
				catch(IOException e)
					{
						e.printStackTrace();

					}
				android.os.Process.killProcess(android.os.Process.myPid());
				/*AlertDialog.Builder builder = new AlertDialog.Builder(ce);
				 builder.setTitle("提示");
				 builder.setMessage("程序崩溃了");
				 builder.setPositiveButton ( "退出", new DialogInterface.OnClickListener ( ){

				 @Override
				 public void onClick ( DialogInterface p1, int p2 )
				 {android.os.Process.killProcess(android.os.Process.myPid());

				 // TODO: Implement this method
				 }
				 } );
				 builder.create().show();*/

			}
	}

