package com.huanmengz.zhanjian2;

import android.content.*;
import android.graphics.*;
import android.os.*;
import android.support.design.widget.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.widget.CompoundButton.*;
import java.io.*;

import android.view.View.OnClickListener;
import android.app.*;
import android.net.*;
import android.*;
import android.widget.AdapterView.*;
import android.content.pm.*;

//no root ver
public class MainActivity extends AppCompatActivity 
{	private static android.support.v7.widget.Toolbar toolbar;
	public static final boolean de = true;
	private static SharedPreferences.Editor editor;
	private static final String tpackname = "com.huanmeng.zhanjian2";
	public static final String pkg()
	{
		String rt;
		if (de)
		{rt = "com.huanmengz.zhanjian2";}
		else
		{rt = tpackname;}
	
		return rt;
	}
	private final String ccbDir()
	{
		String str = getFilesDir().toString();
		String s = str + "/hot/ccbResources";
		return s ;
	}
	public String[] fileslist()
	{
		String[] fllist= null;
		try
		{
			fllist = this.getResources().getAssets().list("resjp");
		}
		catch (IOException e)
		{}
		return fllist;
	}
	public boolean isAdv()
	{
		boolean rt;
		boolean v;
		rt = pref().getBoolean("isAdv", false);
		if (!rt)
		{return false;}
		long g = pref().getLong("encode", 0);
		if (g == 0)
		{Toast.makeText(MainActivity.this, R.string.failed, 3000).show();return false;}
		/*long h = code.decode(code.decode(g));
		 if(h==imei.getIMEI(this)){return true;}*/
		v = reg.verifyAccess(imei.getIMEI(this), g);
		return v;
	}

	private  final String flpth()
	{
		return getFilesDir().toString();
	}
	private static final String prpth ="/data/data/" + pkg() + "/shared_prefs";
	private static final String cos ="Cocos2dxPrefsFile";
	private static final String cocos =prpth + "/Cocos2dxPrefsFile.xml";
	public static final int version=2016032000;
	private boolean s = true;
	public boolean isOvrd()
	{

		return pref().getBoolean("isOverride", false);
	}



	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		String lpp="a";
		ExceptionHandler.getInstance().init(this);
		reg.init(this);
		way.init(this);
		super.onCreate(savedInstanceState);

		setContentView(R.layout.main);
		
		int iu = pref().getInt("ver", 0);
		if (iu != version)
		{showcglog();delpoyfile();}
		
		toolbar = (android.support.v7.widget.Toolbar)findViewById(R.id.toolbar);
		final Button btjp =(Button)findViewById(R.id.btjp);
		final Button btzh =(Button)findViewById(R.id.btzh);
		final Button btkr =(Button)findViewById(R.id.btkr);
		final TextView stat1 =(TextView)findViewById(R.id.stat1);
		final RelativeLayout rl= (RelativeLayout)findViewById(R.id.rl);
		Cg.setMainLayout(rl);
		Cg.setmain((LinearLayout)findViewById(R.id.ll));
		//移出第三个按钮
		rl.removeView(btkr);
		
		//TextView stat2 = (TextView)findViewById(R.id.stat2);
		setSupportActionBar(toolbar);
		Cg.setToolbar(toolbar);
		btjp.setText(R.string.btjp);
		btzh.setText(R.string.btzh);
		btkr.setText(R.string.btkr);
		stat1.setText(R.string.textm);
		


		/*hdl = new Handler(){
		 @Override
		 public void handleMessage(Message msg){

		 }
		 };*/

		setstat2();

	}
	public void mview(View torm){
		toolbar = (android.support.v7.widget.Toolbar)findViewById(R.id.toolbar);
		LinearLayout ll = (LinearLayout)findViewById(R.id.ll);
		final RelativeLayout rl= Cg.getMainLayout();
		
		//移出第三个按钮
		ll.removeView(torm);
		ll.addView(rl);
		final Button btjp =(Button)findViewById(R.id.btjp);
		final Button btzh =(Button)findViewById(R.id.btzh);
		final Button btkr =(Button)findViewById(R.id.btkr);
		final TextView stat1 =(TextView)findViewById(R.id.stat1);
		
		//TextView stat2 = (TextView)findViewById(R.id.stat2);
		toolbar.setTitle(R.string.app_name);
		toolbar.setNavigationIcon(null);
		toolbar.setNavigationOnClickListener(null);
		setSupportActionBar(toolbar);
		
		btjp.setText(R.string.btjp);
		btzh.setText(R.string.btzh);
		stat1.setText(R.string.textm);
		setstat2();
		
	
}
	@Override
	public void onStart()
	{

		// TODO: Implement this method
		super.onStart();
		fileslist();
		ckERR();
		Log.d("ckerr", "ckerr");
		int v = pref().getInt("ver", 0);
		if (v != version)
		{Log.d("update", "now");
			showcglog();
			delpoyfile();}
		File ex = new File(Environment.getExternalStorageDirectory() + "/exciting");
		if (!ex.isDirectory())
		{egg();}

		//test();

	}
	public final void wipechange()
	{
		String[] fllist=fileslist();
		int q = fllist.length;
		for (int i=0;i < q;i++)
		{
			File fl = new File(ccbDir() + "/" + fllist[i]);
			if (fl.exists())
			{fl.delete();}
		}
	}

	public final void Udo(View v)
	{
		LinearLayout ll =(LinearLayout)findViewById(R.id.ll);
		Snackbar.make(ll, R.string.udo, Snackbar.LENGTH_LONG).show();
	}

	public final void btzh(View v)
	{
		final LinearLayout ll =(LinearLayout)findViewById(R.id.ll);
		boolean a = able();
		if (!a)

		{Snackbar.make(ll, R.string.vererr, Snackbar.LENGTH_LONG).show();newver();return;}
		final String name ="cocoszh.xml";
		String file = flpth() + "/" + name;
		execShell("cat " + file + " > " + cocos);
		wipechange();
		way.CopyAssets("reszh", ccbDir());


		editor = pref().edit();
		editor.putString("CurrLan", "Chinese");
		editor.commit();

		setstat2();

		android.support.v7.app.AlertDialog.Builder b = new android.support.v7.app.AlertDialog.Builder(MainActivity.this);
		b.setTitle(R.string.notice).setMessage(R.string.succes).setPositiveButton(R.string.ok, null).show();


	}
	public final void btjp(View v)
	{
		//android.support.v7.widget.AppCompatButton btn=new android.support.v7.widget.AppCompatButton(this);
		final LinearLayout ll =(LinearLayout)findViewById(R.id.ll);
		boolean a = able();
		if (!a)
		{Snackbar.make(ll, R.string.vererr, Snackbar.LENGTH_LONG).show();newver();return;}
		final String name ="cocosjp.xml";
		String file = flpth() + "/" + name;
		execShell("cat " + file + " > " + cocos);
		wipechange();
		way.CopyAssets("resjp", ccbDir());
		editor = pref().edit();
		editor.putString("CurrLan", "Japanese");
		editor.commit();

		setstat2();

		android.support.v7.app.AlertDialog.Builder b = new android.support.v7.app.AlertDialog.Builder(MainActivity.this);
		b.setTitle(R.string.notice).setMessage(R.string.succes).setPositiveButton(R.string.ok, null).show();

		//Snackbar.make ( ll, R.string.succes, Snackbar.LENGTH_LONG).show ( );

		// TODO: Implement this method






		//	while(t.isAlive()){}


	}

	public final void delpoyfile()
	{
		final String fileName[]={"cocosjp.xml","cocoszh.xml","may.sh"};
		int full = 3;
		Log.d("Copyfiles", "Total:" + String.valueOf(fileName.length));
		//int l = 0;
		//直接复制到/files用cat;
		

		for (int q =0;q < full;q++)
		{
			try
			{
				//拿到输入流
				InputStream in = getAssets().open(fileName[q]);
				//打开输出流
				FileOutputStream out = openFileOutput(fileName[q], MODE_PRIVATE);
				int len = -1 ;
				byte[] bytes = new byte[1024 * 1024];
				//不断读取输入流
				while ((len = in.read(bytes)) != -1)
				{
					//写到输出流中
					out.write(bytes, 0, len);
				}
				out.close();
				in.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();

			}
			

			// TODO: Implement this method
		}

		//if(code==0){mp.cancel();}
		//sn.dismiss();
		//sn.dismiss();
		editor = pref().edit();
		editor.putInt("ver", version);
		editor.commit();





	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{if (keyCode == KeyEvent.KEYCODE_BACK)
		{if(!s){
		s=true;
		RelativeLayout rlx=Cg.getRelativeLayout();
		rlx.removeAllViewsInLayout();
		rlx.removeAllViews();
	
		mview(rlx);
		
		return true;}
			android.support.v7.app.AlertDialog.Builder builder =new android.support.v7.app.AlertDialog.Builder(MainActivity.this);
			builder.setMessage(R.string.exit_msg);
			builder.setTitle(R.string.confirm);
			builder.setIcon(R.drawable.ico_warn);
			builder.setPositiveButton(R.string.exit, new DialogInterface.OnClickListener(){
					public void onClick(DialogInterface dialog, int whichButron)
					{

						android.os.Process.killProcess(android.os.Process.myPid());}
				});
			builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener(){
					public void onClick(DialogInterface dialog, int whichButron)
					{
					}});
			builder.show();}
		// TODO: Implement this method
		return true;
	}

	public void egg()
	{
		final RelativeLayout rl =(RelativeLayout)findViewById(R.id.rl);
		final Button egg = new Button(this);
		rl.addView(egg);

		RelativeLayout.LayoutParams lpegg =(RelativeLayout.LayoutParams)egg.getLayoutParams();

		lpegg.addRule(rl.ALIGN_PARENT_TOP | rl.ALIGN_PARENT_RIGHT);

		egg.setLayoutParams(lpegg);
		egg.setText("egg");
		egg.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{	File ex = new File(Environment.getExternalStorageDirectory() + "/exciting");
					if (ex.isFile())
					{ex.delete();}
					if (ex.isDirectory())
					{return;}
					ex.mkdir();
					rl.removeView(egg);
					// TODO: Implement this method
				}
			});



	}	
	public void vererr()
	{

	}
	public boolean able()
	{
		if (isOvrd())
		{return true;}
		LinearLayout ll = (LinearLayout)findViewById(R.id.ll);
		String str =co().getString("DataVersionId", "0");
		Toast.makeText(MainActivity.this,str,3000).show();
		int i=Integer.valueOf(str).intValue();
		if (i == 0)
		{Snackbar.make(ll, R.string.vererr, Snackbar.LENGTH_LONG).show();return false;}
		if (version >= i)
		{return true;}
		else
		{return false;}


	}
	public  boolean onCreateOptionsMenu(Menu menu)
	{

// TODO Auto-generated method stub
		MenuInflater mInflater = getMenuInflater();
		mInflater.inflate(R.menu.menu, menu);
		if (!s)
		{menu.removeItem(R.id.menu0);}
		return true;

	}
	public  boolean onOptionsItemSelected(MenuItem item) 
	{	
		switch (item.getItemId())
		{
			case R.id.menu0:
				setting();
				break;
			case R.id.menu1:
				android.support.v7.app.AlertDialog.Builder bl = new android.support.v7.app.AlertDialog.Builder(this);
				bl.setTitle(R.string.about);
				bl.setMessage(R.string.about_msg_ja);
				bl.setPositiveButton(R.string.close, null);
				bl.create().show();

				break;
			case R.id.menu2:
				android.support.v7.app.AlertDialog.Builder builder =new android.support.v7.app.AlertDialog.Builder(MainActivity.this);
				builder.setMessage(R.string.exit_msg);
				builder.setTitle(R.string.confirm);
				builder.setIcon(R.drawable.ico_warn);
				builder.setPositiveButton(R.string.exit, new DialogInterface.OnClickListener(){
						public void onClick(DialogInterface dialog, int whichButron)
						{
							/*Intent ext = new Intent();
							 ext.setClass(.this,MainActivity.class);
							 ext.putExtra("EXIT",true);
							 ext.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
							 startActivity(ext);*/

							android.os.Process.killProcess(android.os.Process.myPid());
							System.exit(0);
						}});
				builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener(){
						public void onClick(DialogInterface dialog, int whichButron)
						{
						}});
				builder.create().show();

		}return true;
	}
	public void poi()
	{}
	public void init()
	{


		File ex = new File(Environment.getExternalStorageDirectory() + "/exciting");
		if (!ex.isDirectory())
		{egg();}
	}



	public static final void execShell(String cmd)
	{ 
		try
		{ 
			//权限设置 
			java.lang.Process p = Runtime.getRuntime().exec("sh"); 
			//获取输出流 
			OutputStream outputStream = p.getOutputStream(); 
			DataOutputStream dataOutputStream=new DataOutputStream(outputStream); 
			//将命令写入 
			dataOutputStream.writeBytes(cmd); 
			//提交命令 
			dataOutputStream.flush(); 
			//关闭流操作 
			//di.close();
			//in.close();
			dataOutputStream.close(); 
			outputStream.close(); } 
		catch (Throwable t)
		{ t.printStackTrace();}
	}	

	public SharedPreferences pref()
	{
		SharedPreferences pre=this.getSharedPreferences("translator", 0);

		editor = pre.edit();
		boolean f = pre.getBoolean("FirstStart", true);
		if (f)
		{
			editor.putBoolean("FirstStart", false);
			editor.commit();}
		return pre;
	}
	public SharedPreferences co()
	{
		SharedPreferences p =this.getSharedPreferences(cos, 0);
		return p;
	}
	public String statii()
	{


		editor = pref().edit();
		String l = pref().getString("CurrLan", null);
		if (l == null)
		{l = "Chinese";editor.putString("CurrLan", "Chinese");editor.commit();}

		return l;
	}
	final public void setstat2()
	{
		final TextView stat2=(TextView)findViewById(R.id.stat2);
		final String tmp=statii();
		if (tmp.equals("Chinese"))
		{stat2.setText(R.string.zh);}
		else if (tmp.equals("Japanese"))
		{stat2.setText(R.string.jp);}
		else if (tmp.equals("Korean"))
		{stat2.setText(R.string.kr);}
	}
	public final void ckERR()
	{
		final String to = "/sdcard/err-log/";
		final String erpth="/data/data/" + pkg() + "/app_error";
		File fl = new File(erpth);
		File fo = new File(to);
		if (!fo.exists())
		{fo.mkdirs();}
		if (fl.exists())
		{android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);
			builder.setTitle(R.string.notice);
			builder.setMessage("程序在上次运行时意外退出，错误日志将保存到/sdcard/err-log/下" + "\nPlease e-mail to developers by the following address:chh2000day@gmail.com");
			builder.setPositiveButton(R.string.ok, null);
			builder.create().show();
			execShell("cp " + erpth + "/*" + " " + to);
			execShell("rm -rf " + erpth);
		}}
	public void setting()
	{	
		s = false;
		final LinearLayout ll = (LinearLayout)findViewById(R.id.ll);
		final RelativeLayout rl = (RelativeLayout)findViewById(R.id.rl);
		final RelativeLayout rl2 = new RelativeLayout(this);
		rl2.setId(88888);
		TextView settxb1 = new TextView(this);
		rl2.addView(settxb1);
		settxb1.setId(100001);
		RelativeLayout.LayoutParams lptx = (RelativeLayout.LayoutParams)settxb1.getLayoutParams();

		ll.removeView(rl);
		ll.addView(rl2);
		CardView sett1 = new CardView(this);
		sett1.setId(100000);
		settxb1.setId(010000);
		settxb1.setText(R.string.advance);
		settxb1.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
		lptx.addRule(rl2.ALIGN_PARENT_LEFT);
		lptx.addRule(rl2.BELOW, 100000);
		settxb1.setLayoutParams(lptx);
		final RelativeLayout settrl1 = new RelativeLayout(this);
		final AppCompatCheckBox settck1 = new AppCompatCheckBox(this);
		if (pref().getBoolean("isOverride", false))
		{settck1.setChecked(true);}
		else
		{pref().edit().putBoolean("isOverride", false).commit();}
		TextView settte1 = new TextView(this);
		TextView s2 = new TextView(this);
		settrl1.addView(s2);
		s2.setText(R.string.ovrd);
		settte1.setText(R.string.override_md);
		settte1.setTextSize(28);
		sett1.addView(settrl1);
		settrl1.addView(settte1);
		//s2.setId(0002);
		settte1.setId(0002);
		RelativeLayout.LayoutParams s1lp = (RelativeLayout.LayoutParams)s2.getLayoutParams();
		s1lp.addRule(settrl1.ALIGN_LEFT);
		s1lp.addRule(settrl1.BELOW, 0002);

		s2.setLayoutParams(s1lp);

		RelativeLayout.LayoutParams settte1lp =(RelativeLayout.LayoutParams)settte1.getLayoutParams();
		settte1lp.addRule(settrl1.ALIGN_PARENT_LEFT);
		settte1.setLayoutParams(settte1lp);
		settrl1.addView(settck1);
		RelativeLayout.LayoutParams settck1lp=(RelativeLayout.LayoutParams)settck1.getLayoutParams();
		settck1lp.addRule(settrl1.ALIGN_PARENT_RIGHT);
		settck1lp.addRule(settrl1.CENTER_VERTICAL);
		settck1.setLayoutParams(settck1lp);
		Cg.setLayout(rl2);
		settck1.setOnCheckedChangeListener(new OnCheckedChangeListener(){

				@Override
				public void onCheckedChanged(CompoundButton p1, boolean p2)
				{	
					if (p2 && !pref().getBoolean("isOverride", false))
					{
						android.support.v7.app.AlertDialog.Builder bu = new android.support.v7.app.AlertDialog.Builder(MainActivity.this);
						bu.setTitle(R.string.confirm);
						bu.setMessage(R.string.ovrdmsg);
						bu.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener(){

								@Override
								public void onClick(DialogInterface p1, int p2)
								{	settck1.setChecked(false);
									pref().edit().putBoolean("isOverride", false).commit();
									// TODO: Implement this method
								}


							});
						bu.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener(){

								@Override
								public void onClick(DialogInterface p1, int p2)
								{pref().edit().putBoolean("isOverride", true).commit();

									// TODO: Implement this method
								}
							});
						bu.show();
					}

					if (!p2)
					{pref().edit().putBoolean("isOverride", false).commit();}
					// TODO: Implement this method
				}


			});
		rl2.addView(sett1);
		toolbar = (android.support.v7.widget.Toolbar)findViewById(R.id.toolbar);
		toolbar.setNavigationIcon(R.drawable.abc_ic_ab_back_mtrl_am_alpha);
		setSupportActionBar(toolbar);
		CardView sett2 = new CardView(this);
		rl2.addView(sett2);
		sett2.setOnClickListener(new adv1());
		RelativeLayout.LayoutParams sett2lp = (RelativeLayout.LayoutParams)sett2.getLayoutParams();
		sett2lp.addRule(rl2.BELOW, 010000);
		sett2lp.width = sett2lp.MATCH_PARENT;
		sett2.setLayoutParams(sett2lp);

		RelativeLayout settrl2 = new RelativeLayout(this);
		TextView settte2m = new TextView(this);
		settte2m.setText(R.string.advance);
		settte2m.setTextSize(28);
		TextView settte2s = new TextView(this);
		sett2.addView(settrl2);
		settrl2.addView(settte2m);
		settrl2.addView(settte2s);
		settte2m.setId(20000);
		RelativeLayout.LayoutParams settte2mlp = (RelativeLayout.LayoutParams)settte2m.getLayoutParams();
		RelativeLayout.LayoutParams settte2slp = (RelativeLayout.LayoutParams)settte2s.getLayoutParams();
		settte2mlp.addRule(settrl2.ALIGN_PARENT_TOP);
		settte2mlp.addRule(settrl2.ALIGN_PARENT_LEFT);
		settte2m.setLayoutParams(settte2mlp);
		settte2slp.addRule(settrl2.ALIGN_PARENT_LEFT);
		settte2slp.addRule(settrl2.BELOW, 20000);
		settte2s.setLayoutParams(settte2slp);
		toolbar.setNavigationOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{mview(Cg.getRelativeLayout());
					s = true;
					toolbar.setNavigationIcon(null);
					toolbar.setNavigationOnClickListener(null);
					setSupportActionBar(toolbar);
					// TODO: Implement this method
				}
			});
	}
	public void newver()
	{
		final String ur = "http://1drv.ms/1Lm5113";
		android.support.v7.app.AlertDialog.Builder builder= new android.support.v7.app.AlertDialog.Builder(MainActivity.this);
		builder.setTitle(R.string.notice);
		builder.setMessage(R.string.updatemsg);
		builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					// TODO: Implement this method
				}
			});
		builder.setPositiveButton(R.string.update, new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2)
				{Intent intent = new Intent();
					intent.setAction("android.intent.action.VIEW");
					Uri conn= Uri.parse(ur);
					intent.setData(conn);
					startActivity(intent);
					// TODO: Implement this method
				}
			});
		builder.show();

	}
	public void showcglog()
	{
		Log.d("Totice", "succes");
		android.support.v7.app.AlertDialog.Builder bl = new android.support.v7.app.AlertDialog.Builder(MainActivity.this);
		bl.setTitle(R.string.changelog);
		bl.setMessage(R.string.changelog_msg);
		bl.setPositiveButton(R.string.close, new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					// TODO: Implement this method
				}
			});
		bl.show();
	}

	public class adv1 implements OnClickListener
	{

		@Override
		public void onClick(View p1)
		{
			if (!isAdv())
			{android.support.v7.app.AlertDialog.Builder bl = new android.support.v7.app.AlertDialog.Builder(MainActivity.this);
				bl.setTitle(R.string.register);
				LayoutInflater li=LayoutInflater.from(MainActivity.this);
				final View ma = li.inflate(R.layout.verify, null);
				bl.setView(ma);

				Button gen =(Button)ma.findViewById(R.id.vergen);
				final EditText tf1=(EditText)ma.findViewById(R.id.vertf1);
				
				final EditText tf2=(EditText)ma.findViewById(R.id.vertf2);
				gen.setOnClickListener(new OnClickListener(){

						@Override
						public void onClick(View p1)
						{String u = reg.getSignCode();
							//Toast.makeText(MainActivity.this,p,20000).show();
							tf1.setText(u);

							// TODO: Implement this method
						}
					});
				bl.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener(){

						@Override
						public void onClick(DialogInterface p1, int p2)
						{
							// TODO: Implement this method
						}
					});
				bl.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener(){

						@Override
						public void onClick(DialogInterface p1, int p2)
						{String cde= tf1.getText().toString();
							String ke = tf2.getText().toString();
							String key =ke.toLowerCase();
							long lged = code.encode1(code.encode(Long.parseLong(cde)));
							if (reg.VerifyAble(cde, key))
							{
								pref().edit().putBoolean("isAdv", true).putLong("encode", lged).commit();
								toolboxes();
							}
							else
							{Toast.makeText(MainActivity.this, R.string.failed, 5000).show();}
							// TODO: Implement this method
						}
					});
				bl.setCancelable(false);

				bl.show();
				// TODO: Implement this method
			}
			else
			{toolboxes();
			}
		}


	}
	public final void toolboxes()
	{LayoutInflater ri = LayoutInflater.from(MainActivity.this);
	s=false;
	View r = ri.inflate(R.layout.vg,null);
	RelativeLayout rl =(RelativeLayout) r.findViewById(R.id.srl);
	Cg.getRelativeLayout().removeAllViews();
	Cg.getRelativeLayout().removeAllViewsInLayout();
	Cg.getMain().removeView(Cg.getRelativeLayout());
	Cg.setLayout(rl);
	GetInfo torec= new GetInfo();
	final String[] infos = torec.getInfo();
	final String[] manifest = torec.getManifest();
	final boolean[] en=torec.getEnable();
	final String[] pth=torec.getPar();
	if(infos==null||manifest==null||en==null||pth==null){
	Snackbar.make(Cg.getMain(),"ERROR!!!NullPointer!!!",5000).show();
	rl.removeAllViews();
	rl.removeAllViewsInLayout();
	mview(rl);
	return;
	}
	Cg.getMain().addView(rl);
	ListView lv= (ListView)rl.findViewById(R.id.lv1);
	vgadpart vg = new vgadpart(MainActivity.this,pth,infos,en);
	lv.setAdapter(vg);
	lv.setOnItemClickListener(new OnItemClickListener(){

				@Override
				public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4)
				{
					String mani=manifest[p3];
					try
					{
						File flp = new File(getFilesDir()+"/"+"may.sh");
						flp.setExecutable(true);
						flp.setWritable(true);
						
						String gph = flp.getAbsolutePath();
						Datainfo di = new Datainfo(mani,gph);
						String[] dataname=di.getDataname();
						int[] path=di.getPath();
						
						if((path==null||dataname==null)||(path.length!=dataname.length)){
							throw new ManifestException("Manifest miss match");
						}
						File f1 = new File(manifest[p3]).getParentFile();
						String f2 = f1.getAbsolutePath();
						for(int i=0;i<dataname.length;i++){
							File f3=new File(f2+"/"+dataname[i]);
							if(!f3.exists()){throw new ManifestException("Mod incorrect!");}
						}
						android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(MainActivity.this);
						builder.setTitle(R.string.confirm);
						builder.setMessage(R.string.confirm);
						builder.setNegativeButton(R.string.cancel,null);
						builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener(){

								@Override
								public void onClick(DialogInterface p1, int p2)
								{
									// TODO: Implement this method
								}
							});
							builder.create().show();
					}
					catch (ManifestException e)
					{Snackbar.make(p1,e.getMessage(),3000).show();
						
					}
					// TODO: Implement this method
				}
			});
	//Cg.getMain().addView(lv);
	}
	public class vgadpart extends BaseAdapter
	{
		String[] datas;
		String[] infos;
		boolean[] ens;
		Context context;
		public vgadpart(Context ctx,String[] data,String[] info,boolean[] situation){
			super();
			datas=data;
			infos=info;
			ens=situation;
			context=ctx;
			
		}
		@Override
		public int getCount()
		{
			
			// TODO: Implement this method
			return infos.length;
		}

		@Override
		public Object getItem(int p1)
		{
			// TODO: Implement this method
			return null;
		}

		@Override
		public long getItemId(int p1)
		{
			// TODO: Implement this method
			return 0;
		}

		@Override
		public View getView(int p1, View p2, ViewGroup p3)
		{
			LayoutInflater layoutinflater=  LayoutInflater.from(context);
			ViewGroup vg =(ViewGroup)layoutinflater.inflate(R.layout.opt,null);
			TextView tvtitle=(TextView)vg.findViewById(R.id.itemtitle);
			TextView tvinfo=(TextView)vg.findViewById(R.id.iteminfo);
			TextView tvsituation =(TextView)vg.findViewById(R.id.itemsituation);
			tvtitle.setText(datas[p1]);
			tvinfo.setText(infos[p1]);
			if(ens[p1]){tvsituation.setText("enabled");}
			else{tvsituation.setText("disable");}
			
			
			// TODO: Implement this method
			return vg;
		}

		
	}
	
	
}
