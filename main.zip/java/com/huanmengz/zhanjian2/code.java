package com.huanmengz.zhanjian2;

public class code
{
	private static final long[] en ={5,1,2,0,3,8,4,7,9,6};
	private static final long[] de ={3,1,2,4,6,0,9,7,5,8};
	private static final long[] en1={5,2,9,3,7,4,0,8,6,1};
	private static final long[] de1={6,9,1,3,5,0,8,4,7,2};
	private static final boolean isNormal(){
		if(en.length<10||de.length<10){return false;}
		else{return true;}}
	public static final long encode(long number){
	String str = Long.toString(number);
	String to = "";
	int le = str.length();
	for(int i=1;i<=le;i++){
		String q = str.substring(i-1,i);
		long w =Long.parseLong(q);
		int t=(int)w;
		long e =en[t];
		String y =Long.toString(e);
		to=to+y;
		
	}
	long p = Long.parseLong(to);
	return p;
	}
	public static final long decode(long number){
		String str = Long.toString(number);
		String to = "";
		int le = str.length();
		for(int i=1;i<=le;i++){
			String q = str.substring(i-1,i);
			long w =Long.parseLong(q);
			int t=(int)w;
			long e =de[t];
			String y =Long.toString(e);
			to=to+y;

		}
		long p = Long.parseLong(to);
		return p;
	}
	public static final long encode1(long number){
		String str = Long.toString(number);
		String to = "";
		int le = str.length();
		for(int i=1;i<=le;i++){
			String q = str.substring(i-1,i);
			long w =Long.parseLong(q);
			int t=(int)w;
			long e =en1[t];
			String y =Long.toString(e);
			to=to+y;

		}
		long p = Long.parseLong(to);
		return p;
	}
	public static final long decode1(long number){
		String str = Long.toString(number);
		String to = "";
		int le = str.length();
		for(int i=1;i<=le;i++){
			String q = str.substring(i-1,i);
			long w =Long.parseLong(q);
			int t=(int)w;
			long e =de1[t];
			String y =Long.toString(e);
			to=to+y;

		}
		long p = Long.parseLong(to);
		return p;
	}
}
