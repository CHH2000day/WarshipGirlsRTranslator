package com.huanmengz.zhanjian2;
import java.io.*;

public class Datainfo extends Object
{private String file;
	private String[] dataname;
	private int[] pthname;
	private String getline="wc -l";
	private String sh ;
	public String[] pths={"/files/hot/ccbResources","/files/hot/ccbResources/animations","/files/hot/ccbResources/arrow","/files/hot/ccbResources/effect","/files/hot/ccbResources/equip","/files/hot/ccbResources/equip_icon_large","/files/hot/ccbResources/extraUI","/files/hot/ccbResourcesgunfire","/files/hot/ccbResources/map","/files/hot/ccbResources/mapLine","/files/hot/ccbResources/model","/files/hot/ccbResources/skill","/files/hot/","/files","/"};
	public Datainfo(String filename,String shpth) throws ManifestException{
		file=filename;
		sh=shpth;
		String lines =execShell(getline+" "+filename);
		String t = lines.substring(0,1);
		int lin = Integer.valueOf(t).intValue();
		System.out.println(t);
		processflname(file,lin);
		File fl=new File(filename);
		String l =fl.getName();
		String p=fl.getParent();
		String h=fl.getPath();
		System.out.println(l+" "+p+" "+h);
		/*if(dataname==null|pthname==null){
		 throw new ManifestException("err");

		 }*/
	}

	public String execShell(String cmd) throws ManifestException{
		String n="";
		try
		{
			Process process= Runtime.getRuntime().exec(cmd);
			BufferedReader er = new BufferedReader(new InputStreamReader(process.getErrorStream()));
			BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String h = er.readLine();
			String tmp= br.readLine();
			if(tmp!=null){
				n=tmp;
			}
			if(h!=null){
				throw new ManifestException("Unable to read mainfest");
			}
		}
		catch (IOException e)
		{

		}
		return n;
	}

	public void processflname(String fle,int num) throws ManifestException{
		if (num==0){return;}
		System.out.println("shelling");
		String[] qr= new String[num];
		System.out.println(String.valueOf(num));
		for (int i=1;i<=num;i++){
			//execShell("cat "+fle);
			String cmd=sh+" "+fle+" "+String.valueOf(i);
			//String cmd="head -"+String.valueOf(i)+" "+fle+" |tail -1";
			String q = execShell(cmd);
			if (i==1&q==null){throw new ManifestException("Failed to read manifest");}
			qr[i-1]=q;

		}
		System.out.println("read complete");
		processdata(qr);


	}
	public void processdata(String[] source) throws ManifestException{
		System.out.println("processing");
		int c = source.length;
		int t =c;
		dataname= new String[t];
		pthname=new int[t];
		System.out.println(String.valueOf(c));
		for (int i =0;i<c;i++){
			String tmp0=source[i];
			int tmp1= tmp0.length();
			String tmp2= tmp0.substring(0,2);
			int tmp3=0;
			try{ tmp3 = Integer.valueOf(tmp2).intValue();}catch(NumberFormatException e){e.printStackTrace();throw new ManifestException("Unable to read path!");}
			pthname[i]=tmp3;
			String tmp4=tmp0.substring(3,tmp1);
			dataname[i]=tmp4;

		}
	}
	public String[] getDataname(){
		return dataname;
	}
	public int[] getPath(){
		return pthname;
	}

}
