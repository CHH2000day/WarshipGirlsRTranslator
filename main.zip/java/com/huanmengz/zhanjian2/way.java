package com.huanmengz.zhanjian2;

import android.content.*;
import android.util.*;
import java.io.*;
import android.app.*;

public class way
{
	public static Context ctx = null;
	public static final int unzip(String zipfile,String targetDir){
	String exec="unzip "+zipfile+" "+"-d "+targetDir;
	MainActivity.execShell(exec);
		return 0;
	}
	public static final void init(Context ct){
		ctx=ct;
	}
	
	public static final void CopyAssets(String assetDir, String dir) {
		String[] files;
		try {
			files = ctx.getResources().getAssets().list(assetDir);
		} catch (IOException e1) {
			return;
		}
		File mWorkingPath = new File(dir);
		//如果文件夹不存在，创建
		if (!mWorkingPath.exists()) {
			if (!mWorkingPath.mkdirs()) {
				Log.e("--CopyAssets--", "创建目录失败");
			}
		}
		Log.d("ready","debug");
		for (int i = 0; i < files.length; i++) {
			try {
				String fileName = files[i];
				//如果名字不包含点，就是文件夹
				if (!fileName.contains(".")) {
					if (0 == assetDir.length()) {
						CopyAssets(fileName, dir + fileName + "/");
					} else {
						CopyAssets(assetDir + "/" + fileName, dir + fileName + "/");
					}
					continue;
				}
				File outFile = new File(mWorkingPath, fileName);
				if (outFile.exists())
					outFile.delete();
				InputStream in = null;
				if (0 != assetDir.length())
					in = ctx.getAssets().open(assetDir + "/" + fileName);
				else
					in = ctx.getAssets().open(fileName);
				OutputStream out = new FileOutputStream(outFile);
				//用一个byte数组从输入流读取写到输出流中
				byte[] buf = new byte[1024*1024];
				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}
				in.close();
				out.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				Log.d("deug","Exception");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
}
