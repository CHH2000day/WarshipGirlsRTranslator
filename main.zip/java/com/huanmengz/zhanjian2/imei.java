package com.huanmengz.zhanjian2;
import android.telephony.*;
import android.content.*;

public class imei
{public static final long getIMEI(Context ctx){
	TelephonyManager tm= (TelephonyManager)ctx.getSystemService(Context.TELEPHONY_SERVICE);
	String imei =tm.getDeviceId();
	return Long.parseLong(imei);
}
}
